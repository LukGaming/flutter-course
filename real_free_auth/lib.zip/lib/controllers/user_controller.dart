import 'package:real_free_auth/models/storage/user.dart';
import 'package:real_free_auth/repositories/user_repository.dart';

class UserController {
  static Future<bool> setUserStorage(data) async {
    final user = LoggedUser(
        idDoUsuario: data["idDoUsuario"],
        nomeDoUsuario: data["nomeDoUsuario"],
        emailDoUsuario: data["emailDoUsuario"],
        telefoneDoUsuario: data["telefoneDoUsuario"],
        statusDoUsuario: data["statusDoUsuario"],
        statusValidacaoConta: data["statusValidacaoConta"],
        tipoDoUsuario: data["tipoDoUsuario"],
        perfilDoUsuario: data["perfilDoUsuario"],
        emailTemporario: data["emailTemporario"],
        token: data["token"],
        dataExpiracaoToken: data["dataExpiracaoToken"],
        refreshToken: data["refreshToken"]);
    var response = await UserRepository.setUserStorage(user);
    if (response == true) return true;
    return false;
  }
}
